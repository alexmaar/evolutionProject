import map.*;
public class World {

    public static void main(String [] arg) throws InterruptedException {
        EvolutionMap map = new EvolutionMap(40,35,18,40, 1, 0.45);


        map.addFirstAnimals(15);


        for (int i=0; i< 1500; i++){
            map.everyDay();
            System.out.println(map);
            Thread.sleep(15,0);;

        }
    }
}

//import simulation.*;
//
//public class World {
//    public static void main(String[] args){
//        Simulation simulation = new Simulation(1000, 100,  10);
//        simulation.run();
//    }
//}
