package parser;
import parameters.*;
public class JsonParser {
    private static final String dir =" ";

    public static Parameters parse (){
        Parameters parameters=null;

//        try (FileReader reader = new FileReader (dir+"/src/startParameters/parameters.json")){
//            Object object = jsonParser.parse(reader);
//            JSONObject jsonObject = (JSONObject) object;
//            int width = ( jsonObject.get("width")).intValue();
//            int height = ( jsonObject.get("height")).intValue();
//            int plantEnergy = ( jsonObject.get("plantEnergy")).intValue();
//            int moveEnergy = ( jsonObject.get("moveEnergy")).intValue();
//            int startEnergy = ( jsonObject.get("startEnergy")).intValue();
//            int animalAmount = ( jsonObject.get("startNumberOfAnimals")).intValue();
//            double jungleRatio = (Double) jsonObject.get("jungleRatio");
//            parameters=new Parameters(width,height,moveEnergy,plantEnergy,jungleRatio,startEnergy,animalAmount);
//            return parameters;
//        } catch (FileNotFoundException fe) {
//            fe.printStackTrace();
//        } catch (IOException ioe) {
//            ioe.printStackTrace();
//        } catch (org.json.simple.parser.ParseException pe ) {
//            pe.printStackTrace();
//        } catch (IllegalArgumentException iex) {
//            System.out.println(iex.toString());
//        }
        return null;

    }

}
