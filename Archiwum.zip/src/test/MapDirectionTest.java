public class MapDirectionTest {
}
